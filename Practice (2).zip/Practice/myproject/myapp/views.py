from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import BlogPost
from .serializers import BlogPostSerializer
from rest_framework import status
import requests
from rest_framework_simplejwt.authentication import JWTAuthentication

from rest_framework.permissions import IsAuthenticated


class BlogPostViewSet(viewsets.ModelViewSet):
    queryset = BlogPost.objects.all()
    serializer_class = BlogPostSerializer
    # permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]



    @action(detail=False, methods=['get'])
    def fetch_and_save_posts(self, request):
        url = 'http://127.0.0.1:8000/blogposts/'

        # Make the GET request
        response = requests.get(url)

        # Check if the request was successful
        if response.status_code == 200:
            blog_posts = response.json()
            for post in blog_posts:
                BlogPost.objects.update_or_create(
                    title=post['title'],
                    defaults={
                        'content': post['content'],
                        'published_date': post['published_date']
                    }
                )
            return Response({'message': 'Successfully saved blog posts to the database'}, status=status.HTTP_200_OK)
        else:
            return Response({'error': f'Failed to retrieve blog posts. Status code: {response.status_code}'}, status=response.status_code)
