# import requests

# # Define the endpoint URL
# url = 'http://127.0.0.1:8000/blogposts/'

# # Make the GET request without headers
# response = requests.get(url)

# # Check if the request was successful
# if response.status_code == 200:
#     blog_posts = response.json()
#     for post in blog_posts:
#         print(f"Title: {post['title']}, Content: {post['content']}, Published Date: {post['published_date']}")
# else:
#     print(f"Failed to retrieve blog posts. Status code: {response.status_code}")
